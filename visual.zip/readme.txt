Visustin v8 Flow chart generator. Demo version.
Copyright 2003-2020 Aivosto Oy
www.aivosto.com

Convert your source code to flow charts. Edit and draw flow charts and
UML activity diagrams.

Supported operating systems: 
 Windows 2000/XP/2003/Vista/7/8/10

Setup troubleshooting:
 If setup fails, run it as Administrator.

Online help:
 https://www.aivosto.com/visustin/help/

License terms:
 See license.txt

Files digitally signed by Aivosto Oy:
 visustin.cab visustin.dll visustin.exe 
 setup.exe setup1.exe st6unst.exe checklib.exe config.exe
 Aivosto Oy cannot guarantee safety if signature is missing or invalid.
 Modified versions may not be used.

URN:NBN:fi-fe201601011003
